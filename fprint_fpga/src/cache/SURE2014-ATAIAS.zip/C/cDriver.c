//Function definitions for cDriver.h

void turnCacheOn(unsigned *CACHE_REG_0, unsigned *CACHE_REG_1, unsigned NCACHE_LINES){
	unsigned int i;
	//this clears the cache before turning it on!
	for(i=0; i<NCACHE_LINES; i++) *CACHE_REG_1 = 0x80000000 | i;
	//Turn cache on
	*CACHE_REG_0 = 0x00000001;
}

void turnCacheOff(unsigned *CACHE_REG_0, unsigned *CACHE_REG_1, unsigned NCACHE_LINES){
	unsigned int i;
	//turn cache off
	for(i=0; i<NCACHE_LINES; i++) *CACHE_REG_1 = 0xC0000000 | i;
	*CACHE_REG_0 = 0x00000000; //any number that is different of 0x0000_0001 is fine!
}

void checkIfCacheIsOn(unsigned *CACHE_REG_0){
	if(*CACHE_REG_0==1) printf("Cache is on\n");
	else printf("Cache is off\n");
}

void flush_cache_line(unsigned *CACHE_REG_1, unsigned cache_line){
	*CACHE_REG_1 = 0xC0000000 | cache_line;
}

void init_cache_line(unsigned *CACHE_REG_1, unsigned cache_line){
	*CACHE_REG_1 = 0x80000000 | cache_line;
}
