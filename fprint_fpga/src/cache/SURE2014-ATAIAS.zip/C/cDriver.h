//Author: Ataias Pereira Reis
//SURE 2014- Summer of 2014 - Summer Undergraduate Research in Engineering
//This is a Cache Driver

//How to use this cache driver?
//Add this file and also the cDriver.c file in your Nios II project.
//In your main program, add #include "cDriver.h" , then use the functions
//remember to set properly the pointers to the control registers, according
//to the cache specification

void turnCacheOn(unsigned *CACHE_REG_0, unsigned *CACHE_REG_1, unsigned NCACHE_LINES);
void turnCacheOff(unsigned *CACHE_REG_0, unsigned *CACHE_REG_1, unsigned NCACHE_LINES);
void checkIfCacheIsOn(unsigned *CACHE_REG_0);
void flush_cache_line(unsigned *CACHE_REG_1, unsigned cache_line);
void init_cache_line(unsigned *CACHE_REG_1, unsigned cache_line);
