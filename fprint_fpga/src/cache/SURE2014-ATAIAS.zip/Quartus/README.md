Nios II with external cache - McGill University - SURE - Summer 2014
=================================

[Nios II](http://www.altera.com/devices/processor/nios2/ni2-index.html) is a soft-core processor developed by Altera. It has options to use a bult-in instruction and data caches. 

Why to design a cache for this processor? The code for this processor is closed source.This means that though it is possible to use it in hardware designs and configure it, one can not visualize the cache signals that are bultin in the processor. If one so desires, what should be done? One option is to design a cache to use with that processor.

The Quartus project files and SystemVerilog cache files are available in the folder in which this README resides. If you want to synthesize the system in order to be able to run Nios II programs on it, do the following:


1. Open Quartus
2. Open project NiosII-SURE.qpf (qpf stands for "Quartus Project File"), found in folder NiosII-SURE
3. Open Qsys. You can click on "Tools" and then "Qsys". Select the file "CPU.qsys" to be opened.
4. Go the the "Library" tab, and just below "Project" you select "cache" and then the button "Edit". Go to "Files" tab and then "Analyze Synthesis Files". After that you can click on Finish and refresh Qsys by clicking F5 (or go to menu "File" then click on "Refresh").
5. Now it is time to generate the system. Click on menu "Generate" and "Generate" again. This opens a window called "Generation". For simulation, select "None", and for testbench select "None" also. For synthesis, let "Create HDL design files for synthesis" as "Verilog". 
6. Click the button "Generate" on the current window. If asked to save anything, say "Yes".
7. Close Qsys if you wish
8. Open the file CPU.v and connect the signal 'coe_interface_data_instruction_readaddress' to 'cpu_instruction_master_address'. Save the file.
9. Go to Quartus main window and go to menu "Processing" then "Start Compilation".
10. Everything should be ok, click on menu "Tools" then "Programmer", select your device and then click "Start" to download your program to the board.

* Observations:
====================
- Currently, this project has the pin assignments for the Cyclone III Starter Kit, the FPGA in this kit is EP3C25F324C6. Some modifications to the project and pin assignments may be needed if you wish to use it with other board.