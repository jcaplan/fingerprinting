/*
 * "Hello World" example.
 *
 * This example prints 'Hello from Nios II' to the STDOUT stream. It runs on
 * the Nios II 'standard', 'full_featured', 'fast', and 'low_cost' example
 * designs. It runs with or without the MicroC/OS-II RTOS and requires a STDOUT
 * device in your system's hardware.
 * The memory footprint of this hosted application is ~69 kbytes by default
 * using the standard reference design.
 *
 * For a reduced footprint version of this template, and an explanation of how
 * to reduce the memory footprint for a given application, see the
 * "small_hello_world" template.
 *
 */

#include <stdio.h>

int enqueue(unsigned *queuePointer, unsigned data);
unsigned dequeue(unsigned *queuePointer);

int main()
{
  printf("Hello from Nios II!\n");
  unsigned *queuePointer = (unsigned *) 0x00011400;
  int i;
  unsigned data, address;
  for(i=0; i<32; i++){
    enqueue(queuePointer+i,i);
  }

  for(i=0; i<16; i++){
    address = dequeue(queuePointer);
      data = dequeue(queuePointer);
      printf("Address %d; Data %d\n", address, data);
  }

  for(i=32; i<80; i++){
      enqueue(queuePointer+i,i);
  }

  for(i=0; i<64; i++){
    address = dequeue(queuePointer);
    data = dequeue(queuePointer);
    printf("Address %d; Data %d\n", address, data);
  }
  return 0;
}

int enqueue(unsigned *queuePointer, unsigned data){
  *queuePointer = data;
  return 0;
}

unsigned dequeue(unsigned *queuePointer){
  return *queuePointer;
}
